@echo off
echo Open this project in Android Studio; the Gradle wrapper JAR is not bundled in this source package.
exit /b 1
