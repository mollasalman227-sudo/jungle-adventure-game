Jungle Adventure - Salman Edition (Android Studio Project)

এই ফোল্ডারটি Android Studio-তে খোলার জন্য তৈরি করা হয়েছে। গেমে আপনার দেওয়া ছবি হিরো চরিত্রের মুখ হিসেবে ব্যবহৃত হচ্ছে। গেমটি landscape/full-screen মোডে চলে।

APK/AAB তৈরি করার নিয়ম:
1. কম্পিউটারে Android Studio (সাম্প্রতিক সংস্করণ) ইনস্টল করুন।
2. Android Studio > Open দিয়ে এই JungleAdventureAndroid ফোল্ডারটি খুলুন।
3. Gradle sync শেষ হতে দিন। প্রয়োজন হলে Android SDK Platform 35 ইনস্টল করুন।
4. পরীক্ষা করার APK: Build > Build Bundle(s) / APK(s) > Build APK(s)
5. Play Store-এর জন্য: Build > Generate Signed Bundle / APK > Android App Bundle নির্বাচন করুন। নতুন upload key তৈরি করে AAB তৈরি করুন এবং নিরাপদে key সংরক্ষণ করুন।
6. Google Play Console-এ developer account, store listing, privacy/data safety ও প্রয়োজনীয় testing সম্পন্ন করে AAB আপলোড করুন।

গুরুত্বপূর্ণ:
- এই পরিবেশে Android SDK/Gradle build tool নেই; তাই এখানে স্বাক্ষরিত APK/AAB কম্পাইল করা সম্ভব হয়নি। এটি Android Studio-তে খোলার সম্পূর্ণ source project।
- package id: com.salman.jungleadventure (Play Store-এ প্রকাশের আগে চূড়ান্ত করে নিন; পরে বদলানো কঠিন)।
- Play Store প্রকাশের জন্য Google Play Console-এর নিজস্ব ফি/নীতি প্রযোজ্য।
